
$PSScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$path = Join-Path -Path $PSScriptRoot "judul_lagu.txt"


$lastTitle = ""


if (!(Test-Path $path)) { "" | Out-File -FilePath $path -Encoding utf8 -Force }

Clear-Host
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "    ENGINE V8.0 - DEEP SCAN ACTIVE       " -ForegroundColor White -BackgroundColor DarkCyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "Monitoring: Edge App / Chrome / Desktop App" -ForegroundColor Yellow

while($true) {

    $allProcs = Get-Process | Where-Object { $_.MainWindowTitle -like "*YouTube Music*" }
    
    if ($allProcs) {
     
        $window = $allProcs[0]
        $rawTitle = $window.MainWindowTitle
        
     
        $currentTitle = $rawTitle -replace " - YouTube Music", ""
        $currentTitle = $currentTitle -replace "YouTube Music", ""
        $currentTitle = $currentTitle -replace " - Microsoft​ Edge", ""
        $currentTitle = $currentTitle -replace " - Google Chrome", ""
        $currentTitle = $currentTitle.Trim()

        if ($currentTitle -ne "" -and $currentTitle -ne "YouTube Music" -and $currentTitle -ne $lastTitle) {
            
            Clear-Host
            Write-Host "==========================================" -ForegroundColor Cyan
            Write-Host "      YT MUSIC - NOW PLAYING             " -ForegroundColor White -BackgroundColor DarkCyan
            Write-Host "==========================================" -ForegroundColor Cyan
            Write-Host "[$(Get-Date -Format HH:mm:ss)] Mode     : Deep Scan (Edge App)" -ForegroundColor Magenta
            Write-Host "[$(Get-Date -Format HH:mm:ss)] Lagu     : $currentTitle" -ForegroundColor Green
            Write-Host "==========================================" -ForegroundColor Cyan
            
          
            $currentTitle | Out-File -FilePath $path -Encoding utf8 -Force
            
            $lastTitle = $currentTitle
        }
    } else {
        
        if ($lastTitle -ne "") {
            Clear-Host
            Write-Host ">>> MENUNGGU YT MUSIC DIBUKA <<<" -ForegroundColor Red
            "" | Out-File -FilePath $path -Encoding utf8 -Force
            $lastTitle = ""
        }
    }
    
   
    Start-Sleep -Seconds 1
}