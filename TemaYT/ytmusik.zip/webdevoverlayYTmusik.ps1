$PSScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$path = Join-Path -Path $PSScriptRoot "judul_lagu.txt"
$lastTitle = ""

if ($null -eq (Get-Job -Name "YTMusicServer" -ErrorAction SilentlyContinue)) {
    $AsyncServer = {
        param($path)
        $listener = New-Object System.Net.HttpListener
        $listener.Prefixes.Add("http://localhost:8080/")
        try {
            $listener.Start()
            while($true) {
                $context = $listener.GetContext()
                $request = $context.Request
                $response = $context.Response
                
                $response.Headers.Add("Access-Control-Allow-Origin", "*")
                $response.Headers.Add("Access-Control-Allow-Methods", "GET, OPTIONS")
                $response.Headers.Add("Access-Control-Allow-Headers", "Content-Type")
                $response.Headers.Add("Cache-Control", "no-cache, no-store, must-revalidate")
                
                if ($request.HttpMethod -eq "OPTIONS") {
                    $response.StatusCode = 200
                    $response.Close()
                    continue
                }

                $response.ContentType = "application/json"
                
                $content = ""
                if (Test-Path $path) {
                    $content = Get-Content -Path $path -Raw -ErrorAction SilentlyContinue
                }

                $data = @{ 
                    title = if($content) { $content.Trim() } else { "Menunggu Musik..." }
                    status = "Active"
                }
                
                $json = $data | ConvertTo-Json
                $buffer = [System.Text.Encoding]::UTF8.GetBytes($json)
                $response.ContentLength64 = $buffer.Length
                $response.OutputStream.Write($buffer, 0, $buffer.Length)
                $response.Close()
            }
        } finally { 
            $listener.Stop() 
        }
    }

    Start-Job -Name "YTMusicServer" -ScriptBlock $AsyncServer -ArgumentList $path
}

Clear-Host
Write-Host "==============================================" -FG Cyan
Write-Host "   YT MUSIC OVERLAY ENGINE - ACTIVE           " -FG Black -BG Yellow
Write-Host "==============================================" -FG Cyan
Write-Host "Server jalan di: http://localhost:8080" -FG Gray
Write-Host "Status: Scanning YouTube Music window..." -FG Gray
Write-Host "----------------------------------------------" -FG White

while($true) {

    $window = Get-Process | Where-Object { $_.MainWindowTitle -like "*YouTube Music*" } | Select-Object -First 1
    
    if ($window) {
        $currentTitle = $window.MainWindowTitle -replace " - YouTube Music", "" -replace "YouTube Music", ""
        $currentTitle = $currentTitle.Trim()

        if ($currentTitle -ne "" -and $currentTitle -ne $lastTitle) {

            $currentTitle | Out-File -FilePath $path -Encoding utf8 -Force
            $lastTitle = $currentTitle
            Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Playing: $currentTitle" -FG Green
        }
    }
    

    Start-Sleep -Seconds 2
}