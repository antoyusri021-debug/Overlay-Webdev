# Engine Webdev YT Music V8.0 - Deep Scan Mode (Edge App Fixed)
$PSScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$path = Join-Path -Path $PSScriptRoot "judul_lagu.txt"

# Variabel memori agar tidak menulis berulang-ulang
$lastTitle = ""

# Pastikan file txt ada
if (!(Test-Path $path)) { "" | Out-File -FilePath $path -Encoding utf8 -Force }

Clear-Host
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "    ENGINE V8.0 - DEEP SCAN ACTIVE       " -ForegroundColor White -BackgroundColor DarkCyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "Monitoring: Edge App / Chrome / Desktop App" -ForegroundColor Yellow

while($true) {
    # DEEP SCAN: Kita cari semua proses yang punya judul 'YouTube Music' 
    # Tanpa peduli dia lagi fokus atau tidak
    $allProcs = Get-Process | Where-Object { $_.MainWindowTitle -like "*YouTube Music*" }
    
    if ($allProcs) {
        # Ambil proses pertama yang ketemu
        $window = $allProcs[0]
        $rawTitle = $window.MainWindowTitle
        
        # Bersihkan sampah judul dari Edge, Chrome, dan PWA
        $currentTitle = $rawTitle -replace " - YouTube Music", ""
        $currentTitle = $currentTitle -replace "YouTube Music", ""
        $currentTitle = $currentTitle -replace " - Microsoft​ Edge", ""
        $currentTitle = $currentTitle -replace " - Google Chrome", ""
        $currentTitle = $currentTitle.Trim()

        # Validasi: Jangan proses kalau judulnya cuma kosong atau cuma 'YouTube Music'
        if ($currentTitle -ne "" -and $currentTitle -ne "YouTube Music" -and $currentTitle -ne $lastTitle) {
            
            Clear-Host
            Write-Host "==========================================" -ForegroundColor Cyan
            Write-Host "      YT MUSIC - NOW PLAYING             " -ForegroundColor White -BackgroundColor DarkCyan
            Write-Host "==========================================" -ForegroundColor Cyan
            Write-Host "[$(Get-Date -Format HH:mm:ss)] Mode     : Deep Scan (Edge App)" -ForegroundColor Magenta
            Write-Host "[$(Get-Date -Format HH:mm:ss)] Lagu     : $currentTitle" -ForegroundColor Green
            Write-Host "==========================================" -ForegroundColor Cyan
            
            # Tulis ke file teks untuk overlay
            $currentTitle | Out-File -FilePath $path -Encoding utf8 -Force
            
            $lastTitle = $currentTitle
        }
    } else {
        # JIKA YT MUSIC BENER-BENER DITUTUP
        if ($lastTitle -ne "") {
            Clear-Host
            Write-Host ">>> MENUNGGU YT MUSIC DIBUKA <<<" -ForegroundColor Red
            "" | Out-File -FilePath $path -Encoding utf8 -Force
            $lastTitle = ""
        }
    }
    
    # Refresh rate dipercepat ke 1 detik biar lebih responsif pas ganti lagu
    Start-Sleep -Seconds 1
}